export const getEventBridgeUrl = () =>
  process.env.REACT_APP_EVENT_BRIDGE_URL;
